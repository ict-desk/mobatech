import { useState } from 'react'

export default function ContactForm({
  subject = 'Contactformulier Mobatech',
  buttonText = 'Verstuur aanvraag',
}) {
  const [message, setMessage] = useState('')

  const handleSubmit = (event) => {
    event.preventDefault()

    setMessage('Formulier is ingevuld. Verzenden wordt later gekoppeld aan Laravel.')
  }

  return (
    <form className="contact-form" onSubmit={handleSubmit} acceptCharset="UTF-8">
      {message && <div className="form-success">{message}</div>}

      <input type="hidden" name="form_name" value="Mobatech contactformulier" />
      <input type="hidden" name="subject" value={subject} />

      <input name="naam" placeholder="Naam" required />
      <input name="email" type="email" placeholder="E-mailadres" required />
      <input name="telefoon" placeholder="Telefoon" />

      <textarea
        name="bericht"
        placeholder={subject}
        required
      />

      <button type="submit">
        {buttonText}
      </button>
    </form>
  )
}