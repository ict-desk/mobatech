export default function MobatechMachinesMockup() {
  const filters = {
    categories: [
      'Zagen',
      'Frezen',
      'Boren',
      'Schuren & borstelen',
    ],
    brands: ['SCM', 'Altendorf', 'Biesse', 'Weinig'],
  };

  const machines = [
    {
      id: 1,
      title: 'SCM Formula Zaagmachine',
      category: 'Zagen',
      brand: 'SCM',
      condition: 'Gebruikt',
      year: 2021,
      material: 'Hout',
      image:
        'https://images.unsplash.com/photo-1517048676732-d65bc937f952?q=80&w=1200&auto=format&fit=crop',
      description:
        'Professionele zaagmachine geschikt voor houtbewerking en seriematig werk.',
    },
    {
      id: 2,
      title: 'Biesse CNC Bewerking Centrum',
      category: 'CNC-bewerken',
      brand: 'Biesse',
      condition: 'Gebruikt',
      year: 2019,
      material: 'Hout',
      image:
        'https://images.unsplash.com/photo-1565008447742-97f6f38c985c?q=80&w=1200&auto=format&fit=crop',
      description:
        'Volautomatische CNC-machine met groot werkbereik.',
    },
    {
      id: 3,
      title: 'Weinig Schaafmachine',
      category: 'Schaven en profileren',
      brand: 'Weinig',
      condition: 'Nieuw',
      year: 2025,
      material: 'Hout',
      image:
        'https://images.unsplash.com/photo-1504307651254-35680f356dfd?q=80&w=1200&auto=format&fit=crop',
      description:
        'Compacte schaafmachine voor nauwkeurige profielbewerking.',
    },
  ];

  return (
    <div className="min-h-screen bg-zinc-100 text-zinc-800">
      <section className="bg-zinc-900 text-white py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <p className="uppercase tracking-[0.25em] text-sm text-orange-400 mb-4">
            Mobatech Holland
          </p>

          <h1 className="text-5xl md:text-6xl font-bold max-w-4xl leading-tight">
            Machines te koop
          </h1>

          <p className="mt-6 text-zinc-300 text-lg max-w-3xl leading-relaxed">
            Overzicht van beschikbare houtbewerkingsmachines, CNC-machines
            en industriële oplossingen.
          </p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-10">
        <div className="bg-white rounded-3xl shadow-sm border border-zinc-200 p-6 mb-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <select className="border border-zinc-300 rounded-xl px-4 py-3 bg-white">
              <option>Categorie</option>
              {filters.categories.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>

            <select className="border border-zinc-300 rounded-xl px-4 py-3 bg-white">
              <option>Merk</option>
              {filters.brands.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>

            <select className="border border-zinc-300 rounded-xl px-4 py-3 bg-white">
              <option>Conditie</option>
              <option>Nieuw</option>
              <option>Gebruikt</option>
            </select>

            <input
              type="text"
              placeholder="Zoek machine..."
              className="border border-zinc-300 rounded-xl px-4 py-3"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {machines.map((machine) => (
            <div
              key={machine.id}
              className="bg-white rounded-3xl overflow-hidden shadow-sm border border-zinc-200 hover:shadow-xl transition-all duration-300"
            >
              <div className="aspect-[16/10] overflow-hidden bg-zinc-200">
                <img
                  src={machine.image}
                  alt={machine.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>

              <div className="p-6">
                <div className="flex items-center gap-2 mb-4 flex-wrap">
                  <span className="bg-orange-100 text-orange-700 text-xs px-3 py-1 rounded-full font-medium">
                    {machine.category}
                  </span>

                  <span className="bg-zinc-100 text-zinc-700 text-xs px-3 py-1 rounded-full font-medium">
                    {machine.condition}
                  </span>
                </div>

                <h2 className="text-2xl font-bold mb-3 leading-tight">
                  {machine.title}
                </h2>

                <div className="space-y-2 text-sm text-zinc-600 mb-5">
                  <div>
                    <strong>Merk:</strong> {machine.brand}
                  </div>

                  <div>
                    <strong>Bouwjaar:</strong> {machine.year}
                  </div>

                  <div>
                    <strong>Geschikt voor:</strong> {machine.material}
                  </div>
                </div>

                <p className="text-zinc-600 leading-relaxed mb-6">
                  {machine.description}
                </p>

                <div className="flex gap-3">
                  <button className="flex-1 bg-zinc-900 text-white rounded-2xl px-5 py-3 font-semibold hover:bg-black transition-colors">
                    Bekijk machine
                  </button>

                  <button className="flex-1 border border-zinc-300 rounded-2xl px-5 py-3 font-semibold hover:bg-zinc-100 transition-colors">
                    Interesse
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
