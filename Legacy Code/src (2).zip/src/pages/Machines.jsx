import { useState } from "react";

const categories = [
  "Zagen",
  "CNC-bewerking",
  "Schaven & profileren",
  "Frezen",
  "Boren",
  "Schuren & borstelen",
  "Afzuiging",
  "Combi-machines",
  "Opsluiten & persen",
];

const machines = [
  {
    id: 1,
    title: "SCM Formula S 35",
    category: "Zagen",
    brand: "SCM",
    condition: "Gebruikt",
    year: "2021",
    material: "Hout",
    image: "/machines/example-machine-1.jpg",
    stockStatus: "op_voorraad",
    shortDescription:
      "Professionele zaagmachine voor nauwkeurig en betrouwbaar zaagwerk.",
    description:
      "Deze SCM zaagmachine is geschikt voor professionele houtbewerking en dagelijks gebruik in een werkplaats.",
  },
  {
    id: 2,
    title: "Altendorf F45",
    category: "Zagen",
    brand: "Altendorf",
    condition: "Gebruikt",
    year: "2019",
    material: "Hout",
    image: "/machines/example-machine-2.jpg",
    stockStatus: "op_voorraad",
    shortDescription: "Formaatzaag voor professioneel gebruik.",
    description:
      "Nette gebruikte formaatzaag met sterke constructie en praktische bediening.",
  },
  {
    id: 3,
    title: "Biesse Rover CNC",
    category: "CNC-bewerking",
    brand: "Biesse",
    condition: "Gebruikt",
    year: "2020",
    material: "Hout",
    image: "/machines/example-machine-3.jpg",
    stockStatus: "op_voorraad",
    shortDescription: "CNC-bewerkingscentrum voor houtbewerking.",
    description:
      "CNC-machine geschikt voor seriematig werk en nauwkeurige bewerkingen.",
  },
];

function CategoryIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path d="M10.8 2.4h2.4l.8 3.1c.6.2 1.1.4 1.6.7l2.8-1.6 1.7 1.7-1.6 2.8c.3.5.5 1 .7 1.6l3.1.8v2.4l-3.1.8c-.2.6-.4 1.1-.7 1.6l1.6 2.8-1.7 1.7-2.8-1.6c-.5.3-1 .5-1.6.7l-.8 3.1h-2.4l-.8-3.1c-.6-.2-1.1-.4-1.6-.7l-2.8 1.6-1.7-1.7 1.6-2.8c-.3-.5-.5-1-.7-1.6l-3.1-.8v-2.4l3.1-.8c.2-.6.4-1.1.7-1.6L3.9 6.3l1.7-1.7 2.8 1.6c.5-.3 1-.5 1.6-.7l.8-3.1Z" />
      <circle cx="12" cy="12" r="3.2" fill="white" />
    </svg>
  );
}

export default function Machines() {
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedMachine, setSelectedMachine] = useState(null);

  const filteredMachines = selectedCategory
    ? machines.filter(
        (machine) =>
          machine.category === selectedCategory &&
          machine.stockStatus === "op_voorraad",
      )
    : [];

  if (selectedMachine) {
    return (
      <main>
        <section className="section section-soft">
          <div className="container two-col machines-grid">
            <div>
              <button
                type="button"
                className="back-button"
                onClick={() => setSelectedMachine(null)}
                aria-label="Terug naar machine overzicht"
              >
                ←
              </button>

              <p className="eyebrow">Te koop</p>

              <h1 className="machines-title">
                <span>{selectedMachine.title}</span>
              </h1>

              <p>{selectedMachine.description}</p>

              <div className="checks checks-light">
                <span>Merk: {selectedMachine.brand}</span>
                <span>Categorie: {selectedMachine.category}</span>
                <span>Conditie: {selectedMachine.condition}</span>
                <span>Bouwjaar: {selectedMachine.year}</span>
                <span>Geschikt voor: {selectedMachine.material}</span>
              </div>

              <a
                className="panel-link"
                href={`/#contact?subject=${encodeURIComponent(
                  `Interesse in ${selectedMachine.title} (${selectedMachine.year})`,
                )}`}
              >
                Ik heb interesse in deze machine <span>→</span>
              </a>
            </div>

            <div className="category-box machine-detail-image-box">
              <img src={selectedMachine.image} alt={selectedMachine.title} />
            </div>
          </div>
        </section>
      </main>
    );
  }

  return (
    <main>
      <section className="section section-soft">
        <div className="container two-col machines-grid">
          <div>
            <p className="eyebrow">Te koop</p>

            <h1 className="machines-title">
              <span>Machines</span>
              <span>op voorraad.</span>
            </h1>

            <p>
              Bekijk de actuele selectie nieuwe en gebruikte
              houtbewerkingsmachines. Kies een categorie om de beschikbare
              machines te tonen.
            </p>
          </div>

          <div className="category-box">
            <h3>Machinecategorieën</h3>

            <div className="category-grid category-grid-icons">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  className={
                    selectedCategory === category
                      ? "category-choice active"
                      : "category-choice"
                  }
                  onClick={() => setSelectedCategory(category)}
                >
                  <i>
                    <CategoryIcon />
                  </i>

                  <b>{category}</b>
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {selectedCategory && (
        <section className="section">
          <div className="container">
            <p className="eyebrow">Beschikbaar</p>

            <h2>Machines in categorie: {selectedCategory}</h2>

            {filteredMachines.length === 0 ? (
              <p>
                Er zijn momenteel geen machines op voorraad in deze categorie.
              </p>
            ) : (
              <div className="cards">
                {filteredMachines.map((machine) => (
                  <article className="card machine-card" key={machine.id}>
                    <img src={machine.image} alt={machine.title} />

                    <div className="card-mark">⚙</div>

                    <h3>{machine.title}</h3>

                    <p>{machine.shortDescription}</p>

                    <p>
                      <strong>Merk:</strong> {machine.brand}
                      <br />
                      <strong>Bouwjaar:</strong> {machine.year}
                      <br />
                      <strong>Conditie:</strong> {machine.condition}
                    </p>

                    <button
                      type="button"
                      className="panel-link panel-link-button"
                      onClick={() => setSelectedMachine(machine)}
                    >
                      Bekijk machine <span>→</span>
                    </button>
                  </article>
                ))}
              </div>
            )}
          </div>
        </section>
      )}
    </main>
  );
}
